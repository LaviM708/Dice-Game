
package dicegame;

import java.util.Scanner;

public class DiceGame {
    static int player1Column = -1;
    static int player2Column = -1;
    
    
    public static void main(String[] args) {
        int players = 3;
        int columns = 11;
        int rounds = 11;
        int[][] scores = new int[players][columns];
        Scanner input = new Scanner(System.in);
        
        
        //loop for each round
        for(int round = 1; round <= rounds; round++) {
            System.out.println("----------------------");
            System.out.println("****** Round " + round + " ******");
            System.out.println("----------------------\n");
            
            //loop for each player
            for (int i = 0; i < players; i++) {
                System.out.println("Player " + (i+1) + " to throw" );
                
                char player;
                do {
                    System.out.println("\n");
                    System.out.println("Enter 't' to take your throw >   ");
                    player = input.next().charAt(0);
                    
                    if (player == 't') {
                        int dice1 = (int) (Math.random() * 6) + 1;
                        int dice2 = (int) (Math.random() * 6) + 1; 
                        int totalScore = dice1 + dice2;
                        
                        System.out.println("[" + dice1 + "][" + dice2 + "]\n");
                        System.out.println("Player " + (i + 1) + " scored " + totalScore + "\n");
                        
                        //player will be asked to choose a column for their score
                        int chosenColumn;
                        do {
                            System.out.print("Enter the column in which you wish to insert your score (2 to 12) >    \n");
                            chosenColumn = input.nextInt();
                            
                            //this will check if the column is empty and unoccupied 
                            if (chosenColumn < 2 || chosenColumn > 12) {
                                System.out.println("Invalid column. Please choose another one.\n");
                            } else if (scores[i][chosenColumn - 2] != 0) {
                                System.out.println("Column " + chosenColumn + " is already selected.\n");
                            } else {
                                //players must choose Different columns for Round 1 
                                if (round == 1) {
                                    if (chooseColumnForRound1(chosenColumn, i)) {
                                        break; // loop will end if choice is valid 
                                    }
                                } else {
                                    //For other rounds player can choose any column
                                    break;
                                }
                            }
                        } while (true);
                        
                        // Record the score
                        scores[i][chosenColumn - 2] = totalScore;
                        
                        //Check for ties
                        for (int otherPlayer = 0; otherPlayer < players; otherPlayer++) {
                            if (otherPlayer == i) continue;
                            int otherPlayerScore = scores[otherPlayer][chosenColumn - 2];

                            // Check if another player has the same score in the chosen column
                            if (otherPlayerScore == totalScore) {
                                System.out.println("It's a tie for column " + chosenColumn + " in round " + round + "!");
                                scores[i][chosenColumn - 2] = -1;
                                break;
                            } else if (totalScore < otherPlayerScore && otherPlayerScore > 0) { 
                                scores[i][chosenColumn - 2] = -1;
                            } else if (otherPlayerScore < totalScore && otherPlayerScore > 0) {
                                scores[otherPlayer][chosenColumn - 2] = -1;
                            }
                        }
                        
                        checkFilledColumns(scores, players);
                        displayTable(scores, players, columns); // updated table with the score
                        break; // 
                    } else {
                        System.out.println("Please press 't' to throw the dice.");
                    }
                } while (player != 't');
            }
        }
        
        System.out.println("The game is now completed.\n");
        findWinner(scores, players);
        System.out.println("Game Analysis \n");
        
    }
    
    //Display Table
    public static void displayTable(int[][] scores, int players, int columns) {
        System.out.print("--------------------------------------------------------------------------------\n");
        System.out.print("|            |");
        for (int i = 2; i <= 12; i++) {
            System.out.printf(" %2d |", i);
        }
        System.out.println("  Scores  |");
        System.out.print("--------------------------------------------------------------------------------\n");

        // Print each player's row
        for (int i = 0; i < players; i++) {
            System.out.printf("|  Player %d  |", i + 1);
            int totalScore = 0;

            for (int u = 0; u < columns; u++) {
                if (scores[i][u] == -1) {
                    System.out.printf("  * |");
                } else if (scores[i][u] != 0) {
                    System.out.printf(" %2d |", scores[i][u]);
                    totalScore += scores[i][u];
                } else {
                    System.out.print("    |");
                }
            }

            // Print the total score for each player
            System.out.printf("  %3d     |\n", totalScore);
            System.out.print("--------------------------------------------------------------------------------\n");
        }
    }
    
    //checks that for Round1 all players should choose different columns
    public static boolean chooseColumnForRound1(int chosenColumn, int playerIndex) {
        if (playerIndex == 0) { // Player 1
            player1Column = chosenColumn;
            return true;
        }
        
        if (playerIndex == 1) { // Player 2
            if (chosenColumn == player1Column) {
                System.out.println("Column " + chosenColumn + " has already been chosen by Player 1. Choose another column.");
                return false;
            }
            player2Column = chosenColumn;
            return true;
        }
            
            
        if (playerIndex == 2) { // Player 3
            if (chosenColumn == player1Column || chosenColumn == player2Column) {
                System.out.println("Column " + chosenColumn + " has already been chosen by another player. Choose another column.");
                return false;
            }
            return true;
        }
        return false;
    }
    
    //prints the result of each column won or tied by players
    public static void checkFilledColumns(int[][] scores, int players) {
        // Iterate through each column
        for (int col = 0; col < scores[0].length; col++) {
            boolean isColumnFilled = true;

            // Check if each player has a non-zero or non-empty value in the column
            for (int row = 0; row < players; row++) {
                if (scores[row][col] == 0) {
                    isColumnFilled = false;
                    break;
                }
            }

            // If all players have filled this column, print the message
            if (isColumnFilled) {
                int highestScore = -1;
                int highScorePlayer = -1;

                // Loop through players to find the highest score in this column
                for (int row = 0; row < players; row++) {
                    if (scores[row][col] > highestScore) {
                        highestScore = scores[row][col];
                        highScorePlayer = row + 1; // Save the player number (1-based)
                    }
                }

                // Print the player with the highest score for the completed column
                if (highestScore > 0) {
                    System.out.println("Column " + (col + 2) + " won by Player " + highScorePlayer);
                } else {
                    System.out.println("Column " + (col + 2) + " was tied.");
                }
            }
        }
    }
    
    //print the winner at the end of the game
    public static void findWinner(int[][] scores, int players) {
        int highestScore = -1;
        int winningPlayer = -1;

        // Iterate through the last column (scores)
        for (int i = 0; i < players; i++) {
            int totalScore = 0;
            for (int j = 0; j < scores[i].length; j++) {
                if (scores[i][j] != -1) { // Only consider valid scores
                    totalScore += scores[i][j];
                }
            }
            
            if (totalScore > highestScore) {
                highestScore = totalScore;
                winningPlayer = i + 1; // 1-based index for players
            }
        }

        // Print the winner details
        if (winningPlayer != -1) {
            System.out.println("Player " + winningPlayer + " wins with a total score of " + highestScore + "!\n");
        } else {
            System.out.println("No winner could be determined.");
        }
    }
    
}
